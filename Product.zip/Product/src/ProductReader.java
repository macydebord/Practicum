import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;

import static java.nio.file.StandardOpenOption.CREATE;

public class ProductReader
{
    public static void main(String[] args)
    {
        String ID = "";
        String name = "";
        String description = "";
        double cost = 0;
        String csvRec = "";
        boolean done = false;

        Scanner in = new Scanner(System.in);

        ArrayList<String> recs = new ArrayList<>();

        do
        {
            ID = SafeInput.getNonZeroLenString(in, "Enter the ID number ");
            name = SafeInput.getNonZeroLenString(in, "Enter the name ");
            description = SafeInput.getNonZeroLenString(in, "Enter the description ");
            cost = SafeInput.getRangedDouble(in, "Enter the cost", 0, 10000000);

            csvRec = ID + ", " + name + ", " + description + ", " + cost;

            recs.add(csvRec);

            done = SafeInput.getYNConfirm(in, "Are you done? ");
        } while (!done);
        File directory = new File(System.getProperty("user.dir"));
        Path file = Paths.get(directory.getPath() + "\\src\\data.txt");

        try
        {
            OutputStream outputStream = new BufferedOutputStream(Files.newOutputStream(file, CREATE));
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outputStream));
            //gave syntax saying a catch clause needed to be added
        } catch (IOException e)
        {
            throw new RuntimeException(e);
        }
    }
}
